//
//  JCHeradNewsImages.h
//  网易新闻ipad
//
//  Created by tarena on 16/2/18.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCHeradNewsImages : NSObject
@property (nonatomic, strong) NSString *imgsrc;
@property (nonatomic, strong) NSString *title;


//@property (nonatomic, strong) NSString *secondImgsrc;
//@property (nonatomic, strong) NSString *secondTitle;
//
//@property (nonatomic, strong) NSString *thirdImgsrc;
//@property (nonatomic, strong) NSString *thirdTitle;
//
//@property (nonatomic, strong) NSString *fourthImgsrc;
//@property (nonatomic, strong) NSString *fourthTitle;
//
//@property (nonatomic, strong) NSString *fifthImgsrc;
//@property (nonatomic, strong) NSString *fifthTitle;
+(JCHeradNewsImages *)parseImageData:(NSDictionary *)Dic;
 @end
