//
//  JCWeather.h
//  网易新闻ipad
//
//  Created by tarena on 16/2/17.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCWeather : NSObject
//城市名字
@property (nonatomic, strong) NSString *cityName;
//天气图标url对应string
@property (nonatomic, strong) NSString *iconUrlStr;
//当前天气的描述
@property (nonatomic, strong) NSString *weatherDesc;
//当前天气的温度
@property (nonatomic, strong) NSString *weatherTemp;
//最高温度
@property (nonatomic, strong) NSString *maxTemp;
//最低温度
@property (nonatomic, strong) NSString *minTemp;
//每小时的时间
@property (nonatomic, strong) NSString *time;
//每天的日期
@property (nonatomic, strong) NSString *date;

//给定每天的字典 返回模型对象
+(id)weatherFromDailyDic:(NSDictionary *)dailyDic;
//给定respondObj，返回模型对象
+(id)weatherFromHeardDic:(id)responseObj;
@end
