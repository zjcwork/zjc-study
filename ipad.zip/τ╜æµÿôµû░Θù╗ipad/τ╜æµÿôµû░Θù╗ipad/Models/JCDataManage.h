//
//  JCDataManage.h
//  网易新闻ipad
//
//  Created by tarena on 16/2/16.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCDataManage : NSObject
//解析天气
+(NSArray *)weatherFromJson:(id)responseObj;

//解析头条新闻
+(NSArray *)heardNewsFromJson:(id)responseObj;

//解析头条图片
+(NSArray *)heardImageFromJson:(id)responseObj;
@end
