//
//  JCDataManage.m
//  网易新闻ipad
//
//  Created by tarena on 16/2/16.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCDataManage.h"
#import "JCHeardNewsData.h"
#import "JCWeather.h"
#import "JCHeradNewsImages.h"
@implementation JCDataManage

+(NSArray *)weatherFromJson:(id)responseObj{
    NSArray *dailyArray = responseObj[@"data"][@"weather"];
    
    NSMutableArray *dailyMutableArray = [NSMutableArray array];

    for (NSDictionary *dailyDic in dailyArray) {
        JCWeather *daily = [JCWeather weatherFromDailyDic:dailyDic];
        [dailyMutableArray addObject:daily];
    }

    return [dailyMutableArray copy];
}

+(NSArray *)heardNewsFromJson:(id)responseObj{

    NSArray *newsData = responseObj[@"T1348647853363"];
    NSMutableArray *newsDataMutableArray = [NSMutableArray array];
    
    for (NSDictionary *Dic in newsData) {
        JCHeardNewsData *newsData = [JCHeardNewsData parseNewsDataJson:Dic];
        [newsDataMutableArray addObject:newsData];
    }

    return [newsDataMutableArray copy];
}

+(NSArray *)heardImageFromJson:(id)responseObj{
    NSArray *newsImage = responseObj[@"T1348647853363"][0][@"ads"];
    NSMutableArray *newsImageMutableArray = [NSMutableArray array];
    
    for (NSDictionary *Dic in newsImage) {
        JCHeradNewsImages *newsImage = [JCHeradNewsImages parseImageData:Dic];
        [newsImageMutableArray addObject:newsImage];
    }


    return [newsImageMutableArray copy];

}
@end
