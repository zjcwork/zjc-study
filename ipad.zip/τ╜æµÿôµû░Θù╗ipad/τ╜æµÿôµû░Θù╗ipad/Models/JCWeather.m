//
//  JCWeather.m
//  网易新闻ipad
//
//  Created by tarena on 16/2/17.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCWeather.h"

@implementation JCWeather
+(id)weatherFromDailyDic:(NSDictionary *)dailyDic{


    return [[self alloc] initWithWithDailyDic:dailyDic];

}

- (id)initWithWithDailyDic:(NSDictionary *)dailyDic {
    if (self = [super init]) {
        //iconUrlStr
        self.iconUrlStr = dailyDic[@"hourly"][0][@"weatherIconUrl"][0][@"value"];
        //        self.iconUrlStr = [self imageMap][self.iconUrlStr];
        //日期
        self.date = dailyDic[@"date"];
        //最高温
        self.maxTemp = [NSString stringWithFormat:@"%@˚",dailyDic[@"maxtempC"]];
        //最低温
        self.minTemp = [NSString stringWithFormat:@"%@˚",dailyDic[@"mintempC"]];
        
    }
    return self;
}


+ (id)weatherFromHeardDic:(id)responseObj{

return [[self alloc] initWithHeaderDic:responseObj];
}

- (id)initWithHeaderDic:(id)responseObj {
    if (self = [super init]) {
        //城市
        self.cityName = responseObj[@"data"][@"request"][0][@"query"];
        NSDictionary *currentDic = responseObj[@"data"][@"current_condition"][0];
        //iconURL
        self.iconUrlStr = currentDic[@"weatherIconUrl"][0][@"value"];
        //        self.iconUrlStr = [self imageMap][self.iconUrlStr];
        //天气描述
        self.weatherDesc = currentDic[@"weatherDesc"][0][@"value"];
        //当前温度
        self.weatherTemp = [NSString stringWithFormat:@"%@˚", currentDic[@"temp_C"]];
        //最高温
        self.maxTemp = [NSString stringWithFormat:@"%@˚", responseObj[@"data"][@"weather"][0][@"maxtempC"]];
        //最低温
        self.minTemp = [NSString stringWithFormat:@"%@˚",responseObj[@"data"][@"weather"][0][@"mintempC"]];
    }
    return self;
    
}

@end
