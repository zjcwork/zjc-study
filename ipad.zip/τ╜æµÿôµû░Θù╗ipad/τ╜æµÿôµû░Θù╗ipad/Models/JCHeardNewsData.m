//
//  JCHeardNewsData.m
//  网易新闻ipad
//
//  Created by tarena on 16/2/17.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCHeardNewsData.h"

@implementation JCHeardNewsData
+(JCHeardNewsData *)parseNewsDataJson:(NSDictionary *)dic{


    return [[self alloc] initWithDataJson:(NSDictionary *)dic];

}

-(JCHeardNewsData *)initWithDataJson:(NSDictionary *)dic{
    if (self = [super init]) {
   
    self.title = dic[@"title"];
    self.digest = dic[@"digest"];
    self.replyCount = dic[@"replyCount"];
    self.url = dic[@"url"];
    self.imgsrc = dic[@"imgsrc"];

    }

    return self;
}
@end
