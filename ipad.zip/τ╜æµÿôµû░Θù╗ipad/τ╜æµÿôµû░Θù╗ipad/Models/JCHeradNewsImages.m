//
//  JCHeradNewsImages.m
//  网易新闻ipad
//
//  Created by tarena on 16/2/18.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCHeradNewsImages.h"

@implementation JCHeradNewsImages
+(JCHeradNewsImages *)parseImageData:(NSDictionary *)Dic{
    
    
    
    return [[self alloc]initWithImageDic:Dic];
}
-(JCHeradNewsImages *)initWithImageDic:(NSDictionary *)Dic{
    if (self = [super init]) {
        self.imgsrc = Dic[@"imgsrc"];
        self.title = Dic[@"title"];
    }

    return self;

}
@end
