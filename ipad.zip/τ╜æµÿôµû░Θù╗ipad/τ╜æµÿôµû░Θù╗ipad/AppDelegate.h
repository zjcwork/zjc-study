//
//  AppDelegate.h
//  网易新闻ipad
//
//  Created by tarena on 16/1/26.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

