//
//  JCMainViewController.h
//  网易新闻ipad
//
//  Created by tarena on 16/1/27.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCMainViewController : UIViewController

@end
