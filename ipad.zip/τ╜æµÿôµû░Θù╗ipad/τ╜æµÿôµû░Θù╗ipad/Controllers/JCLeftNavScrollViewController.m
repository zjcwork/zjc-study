//
//  JCLeftNavScrollViewController.m
//  网易新闻ipad
//
//  Created by tarena on 16/1/26.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCLeftNavScrollViewController.h"
#import "Masonry.h"
#import "JCaaaViewController.h"

@interface JCLeftNavScrollViewController()<UIScrollViewDelegate>
@property (nonatomic,strong) NSMutableArray *buttons;
//当前选中的按钮
@property (nonatomic, strong) UIButton *currentBtn;
@property (nonatomic) int index;

@end
@implementation JCLeftNavScrollViewController




+(JCLeftNavScrollViewController *)creatLeftNav{

    
   
   
    return [[self alloc]creatScrollView];
}


-(JCLeftNavScrollViewController *)creatScrollView{

    JCLeftNavScrollViewController *scrollView = [JCLeftNavScrollViewController new];
    scrollView.userInteractionEnabled = YES ;
    scrollView.backgroundColor = [UIColor blackColor];
    NSArray *array = @[@"",@"头条",@"娱乐",@"体育",@"财经",@"科技",@"汽车",@"本地"];
    UIView *lastView = nil;
    scrollView.contentSize = CGSizeMake(80, 70*(array.count+1)+10);
    for (int i =0; i <array.count; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:array[i] forState:0];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
         [btn setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
        if ( i == 0) {
            _currentBtn = btn;
            btn.selected = YES;
        }
        btn.tag = i;
        
        //btn选中状态改变
        [btn addTarget:self action:@selector(statusChange:) forControlEvents:UIControlEventTouchUpInside];
        
        [scrollView addSubview:btn];
        
        [btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(80, 60));
            if (lastView) {
                make.top.mas_equalTo(lastView.mas_bottom).mas_equalTo(0);
                make.left.mas_equalTo(0);
            }else{
                make.right.mas_equalTo(10);
            }
        }];
        lastView = btn;
        [self.buttons addObject:btn];
        
    }
    
    return scrollView;
}

-(void)statusChange:(UIButton *)sender{
    if (_currentBtn != sender) {
        _currentBtn.selected = NO;
        
        _currentBtn = sender;
        
        _currentBtn.selected = YES;
        
        
    }
    if (_currentBtn.tag == 1) {
        NSLog(@"QQQQQQQ");
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"seclectButton" object:self userInfo:@{@"selectButton":[NSNumber numberWithInt:_currentBtn.tag]}];
    JCaaaViewController *VC = [[JCaaaViewController alloc] init];
    [[UIApplication sharedApplication].keyWindow.rootViewController
     presentViewController:VC animated:YES completion:nil];
    
    
}

 

@end
