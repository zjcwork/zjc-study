//
//  JCHomeHeardView.m
//  网易新闻ipad
//
//  Created by tarena on 16/1/27.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCHomeHeardView.h"
#import "JCWeatherViewController.h"
@implementation JCHomeHeardView

+(JCHomeHeardView *)getHeardView{


    return [[[NSBundle mainBundle] loadNibNamed:@"JCHomeHeardView" owner:self options:nil] firstObject];
}
- (IBAction)chickWeather:(id)sender {
 
  
    NSLog(@"--a-d-asdfafdas");
    
    if ([self.delegate respondsToSelector:@selector(presentController)]) {
        [self.delegate presentController
         ];
        
    }
    NSLog(@"vadslfdgjasfejkwoef");
    
//    JCWeatherViewController *weatherVC = [JCWeatherViewController new];
//    weatherVC.preferredContentSize = CGSizeMake(300, 400);
//    weatherVC.modalPresentationStyle = UIModalPresentationFormSheet;
    
    
//    [[UIApplication sharedApplication].keyWindow.rootViewController
//     presentViewController:weatherVC animated:YES completion:nil];
    
}


@end
