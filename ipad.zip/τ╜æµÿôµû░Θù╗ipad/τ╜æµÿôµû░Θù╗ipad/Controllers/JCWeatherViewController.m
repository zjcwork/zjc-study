//
//  JCWeatherViewController.m
//  网易新闻ipad
//
//  Created by tarena on 16/2/17.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCWeatherViewController.h"
#import "JCWeather.h"
@interface JCWeatherViewController ()
@property (weak, nonatomic) IBOutlet UILabel *cityName;
@property (weak, nonatomic) IBOutlet UILabel *currentTemp;
@property (weak, nonatomic) IBOutlet UILabel *secondDayTemp;
@property (weak, nonatomic) IBOutlet UILabel *thirdDayTemp;
@property (weak, nonatomic) IBOutlet UILabel *fourthDayTemp;
@property (weak, nonatomic) IBOutlet UIImageView *currentWeatherImage;
@property (weak, nonatomic) IBOutlet UIImageView *secondWeatherImage;
@property (weak, nonatomic) IBOutlet UIImageView *thirdWeatherImage;
@property (weak, nonatomic) IBOutlet UIImageView *fourthWeatherImage;

@end

@implementation JCWeatherViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    JCWeather *weather = self.dailyArray[0];
//    self.currentTemp.text = weather.weatherTemp;
//    self.secondDayTemp.text = weather.maxTemp;
    
    
    [self listenNotification];
    
    
    
}
-(void)listenNotification{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenWeatherData:) name:@"getWeatherData" object:nil];



}

-(void)listenWeatherData:(NSNotification *)notufucation{
    JCWeather *weather= notufucation.userInfo[@"WeatherData"][0];
    self.currentTemp.text = weather.weatherTemp;
    self.secondDayTemp.text = weather.maxTemp;


}

- (IBAction)chickClose:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
