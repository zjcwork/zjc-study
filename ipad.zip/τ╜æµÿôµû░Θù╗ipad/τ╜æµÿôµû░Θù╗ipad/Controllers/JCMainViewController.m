 //
//  JCMainViewController.m
//  网易新闻ipad
//
//  Created by tarena on 16/1/27.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCMainViewController.h"
#import "Masonry.h"
#import "JCLeftNavScrollViewController.h"
#import "JCHomeHeardView.h"
#import "JCUserViewController.h"
#import "JCContentView.h"
#import "AFNetworking.h"
#import "JCDataManage.h"
#import <CoreLocation/CoreLocation.h>
#import "TSMessage.h"
#import "TSMessageView.h"
#import "JCWeatherViewController.h"
#import "JCContentOtherView.h"
#import "JCLoadingView.h"
@interface JCMainViewController ()<CLLocationManagerDelegate,UIScrollViewDelegate,JCHomeHeardViewDelegate>
@property (nonatomic , strong) CLLocationManager *manager;
//用户位置
@property (nonatomic, strong) CLLocation *userLocation;
//手选城市
@property (nonatomic, strong) NSString *cityNameStr;
//近几天的天气
@property (nonatomic, strong) NSArray *dailyArray;
//首页图片滚动视图
@property (nonatomic, strong) UIScrollView *sv;

@property (weak, nonatomic) UIPageControl *pc;


@property ( nonatomic) int i;

@property (nonatomic) int seclectButton;


@end

@implementation JCMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self lisenScelectButton];
    [self ConfigurationInterface];
    [self sendRequest];
    [self localNotification];
    
   
}
-(void)lisenScelectButton{

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(seclectButtonNumber:) name:@"selectButton" object:nil];


    

}
-(void)seclectButtonNumber:(NSNotification *)not{
    self.seclectButton = [not.userInfo[@"selectButton"] intValue];
    


}
-(void)localNotification{
    UILocalNotification *localNoti = [UILocalNotification new];
    localNoti.fireDate = [NSDate dateWithTimeIntervalSinceNow:10];
    localNoti.alertBody = @"学习本地通知";
    localNoti.alertTitle = @"本地通知";
    localNoti.alertAction = @"~~~";
    localNoti.applicationIconBadgeNumber = 123;
    [[UIApplication sharedApplication]scheduleLocalNotification:localNoti];
    




}
#pragma  mark -- 配置主界面
-(void)ConfigurationInterface{
    self.view.backgroundColor = [UIColor whiteColor];
    //创建左侧背景
    UIView *backView = [[UIView alloc] init];
    backView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:backView];
    [backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.bottom.mas_equalTo(0);
        make.width.mas_equalTo(80);
    }];
    //创建用户按钮
    UIButton *UserButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [UserButton setImage:[UIImage imageNamed:@"home_channel_bar_portrait"] forState:UIControlStateNormal];
    [self.view addSubview:UserButton];
    [UserButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(80, 58));
        make.left.mas_equalTo(0);
        make.top.mas_equalTo(12);
    }];
    UserButton.backgroundColor = [UIColor blackColor];
    [UserButton addTarget:self action:@selector(toucheUserCentre) forControlEvents:UIControlEventTouchUpInside ];
    //创建左侧导航和add按钮
    JCLeftNavScrollViewController *nav = [JCLeftNavScrollViewController creatLeftNav];
    [self.view addSubview:nav];
    [nav mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(65);
        make.left.mas_equalTo(0);
        make.bottom.mas_equalTo(-90);
        make.width.mas_equalTo(80);
        
    }];
    UIButton *addButton = [UIButton buttonWithType:0];
    [self.view addSubview:addButton];
    addButton.backgroundColor = [UIColor blackColor];
    [addButton setImage:[UIImage imageNamed:@"subs_add"] forState:0];
    [addButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.mas_equalTo(0);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(93);
    }];
    
    //创建头
    JCHomeHeardView *heardView = [JCHomeHeardView getHeardView] ;
    heardView.delegate = self;
    [self.view addSubview:heardView];
    [heardView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.right.mas_equalTo(0);
        make.left.mas_equalTo(80);
        make.height.mas_equalTo(80);
    }];
    
   //创建loading图
    JCLoadingView *loadingVC = [[JCLoadingView alloc] init ];
    [self.view addSubview:loadingVC];
    loadingVC.frame = CGRectMake(80, 80, 900, 650);
     //创建内容视图
    UIScrollView *sv = [[UIScrollView alloc] init];
    // 添加主界面滚动视图
    self.sv = sv;
   // [self.view addSubview:sv];
  
    //添加约束(滚动视图无法使用约束)
    sv.frame = CGRectMake(80, 80, 900, 650);

    sv.backgroundColor = [UIColor blueColor];
    sv.bounces = YES;
    sv.contentSize = CGSizeMake(4*sv.bounds.size.width, sv.bounds.size.height);
    
   
    for (NSInteger i = 0 ; i<4; i++) {
        if (i == 0) {
    
        JCContentView * contentview = [JCContentView getContentView];
            
        contentview.frame = CGRectMake(0, 0, sv.bounds.size.width, sv.bounds.size.height);
       [sv addSubview:contentview];
        }else {
        
            JCContentOtherView * contentOtherView = [JCContentOtherView getContentOtherView];
            
            contentOtherView.frame = CGRectMake(i*sv.bounds.size.width, 0, sv.bounds.size.width, sv.bounds.size.height);
            [sv addSubview:contentOtherView];
            
            
            
       }
  }
    sv.bounces = NO;
    sv.pagingEnabled = YES;
    sv.showsHorizontalScrollIndicator = NO;
    
    //创建PageControl
    UIPageControl *pc = [[UIPageControl alloc] init];
    self.pc = pc;
    sv.delegate =self;
    pc.frame = CGRectMake(0,sv.bounds.size.height - 30, sv.bounds.size.width, 40);
    pc.numberOfPages = 4;
    pc.pageIndicatorTintColor = [UIColor whiteColor];
    pc.currentPageIndicatorTintColor = [UIColor blackColor];
    pc.userInteractionEnabled = NO;
  //  [self.view addSubview:pc];


}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGPoint offset = scrollView.contentOffset;
    
    int index = round(offset.x/scrollView.bounds.size.width);
   
    if (self.i != index) {
        self.i = index ;
  
   [[NSNotificationCenter defaultCenter] postNotificationName:@"pageNumber" object:self userInfo:@{@"pageNumber":[NSNumber numberWithInt:index]}];
        NSLog(@"发送通知");
    NSLog(@"现在在第%d页",index);
    }
   
 
}
#pragma mark -- 点击用户头像后
-(void)toucheUserCentre{
    JCUserViewController *userVC = [JCUserViewController new];
    userVC.preferredContentSize = CGSizeMake(330, 260);
   //设置弹出模式
    userVC.modalPresentationStyle = UIModalPresentationFormSheet;
    [self presentViewController:userVC animated:YES completion:nil];
    
    



}

#pragma mark -- 发送获取新闻请求
- (void)sendRequest{
    
    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(getData) object:nil];
    [thread start];
    
}
-(void)getData{
    NSLog(@"%@",[NSThread currentThread]);
    /*
     娱乐39
     体育
     */
    NSArray *array  = @[@"T1348647853363/0-40",@"T1348648517839/0-20",@"T1348649079062/0-20",@"T1348648756099/0-20",@"T1348649580692/0-20"];
    
   // NSString *urlStr = @"http://c.m.163.com/nc/article/headline/T1348647853363/0-40.html?from=toutiao&";
    NSString *urlStr = [NSString stringWithFormat:@"http://c.m.163.com/nc/article/headline/%@.html?from=toutiao&",array[0]];
    //发送get请求
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/json", @"text/plain", @"text/html", nil];

    [manager GET:urlStr parameters:nil success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
        
                NSArray *newsDataArray = [JCDataManage heardNewsFromJson:responseObject];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"getNewsData" object:self userInfo:@{@"newsData":newsDataArray}];
                NSArray *newsImageArray = [JCDataManage heardImageFromJson:responseObject];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"getNewsImage" object:self userInfo:@{@"newsImageData":newsImageArray}];
            NSLog(@"首页新闻发送请求成功");

         [self.view addSubview:self.sv];
      
    } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
        NSLog(@"%@",error);
        [TSMessage showNotificationWithTitle:@"提示" subtitle:@"请稍后再试" type:TSMessageNotificationTypeWarning];
    }];


}


- (void)presentController {
    JCWeatherViewController *weatherVC = [JCWeatherViewController new];
    weatherVC.preferredContentSize = CGSizeMake(300, 400);
    weatherVC.modalPresentationStyle = UIModalPresentationFormSheet;
    

    [self presentViewController:weatherVC animated:YES completion:nil];
}




@end
