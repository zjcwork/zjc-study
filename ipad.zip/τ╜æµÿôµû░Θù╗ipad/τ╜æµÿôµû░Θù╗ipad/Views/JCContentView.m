//
//  JCContentView.m
//  网易新闻ipad
//
//  Created by tarena on 16/2/16.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCContentView.h"
#import "JCHeardNewsData.h"
#import "JCHeradNewsImages.h"
#import "JCShowViewController.h"

@interface JCContentView()<UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *fristRightTitle;
@property (weak, nonatomic) IBOutlet UILabel *secondRightTitle;
@property (weak, nonatomic) IBOutlet UILabel *thirdRightTitle;
@property (weak, nonatomic) IBOutlet UILabel *bottomLeftTitle;

@property (weak, nonatomic) IBOutlet UILabel *bottomRightTitle;
@property (weak, nonatomic) IBOutlet UIScrollView *imageScroll;
@property (weak, nonatomic) IBOutlet UILabel *fristRightReply;
@property (weak, nonatomic) IBOutlet UILabel *fristRightDigst;
@property (weak, nonatomic) IBOutlet UILabel *secondRightReply;
@property (weak, nonatomic) IBOutlet UILabel *secondRightDigst;
@property (weak, nonatomic) IBOutlet UILabel *thirdRightReply;
@property (weak, nonatomic) IBOutlet UILabel *thirdRightDigst;
@property (weak, nonatomic) IBOutlet UILabel *bottomRightRely;
@property (weak, nonatomic) IBOutlet UILabel *bottonRightDigst;
@property (weak, nonatomic) IBOutlet UILabel *bottomLeftReply;
@property (weak, nonatomic) IBOutlet UILabel *bottomLeftDigst;
@property (weak, nonatomic) IBOutlet UIButton *imageTitle;
@property (weak, nonatomic) UIPageControl *pc;
@property (weak, nonatomic) IBOutlet UIView *view;
@property (nonatomic ,strong) NSArray *imagesArray;
@property (nonatomic ,strong) NSArray *newsArray;


@end
@implementation JCContentView
-(void)awakeFromNib{
    
[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenNewsData:) name:@"getNewsData" object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenNewsImage:) name:@"getNewsImage" object: nil];
    
    

}
-(void)listenNewsImage:(NSNotification *)notifcation{
    
  
    self.imagesArray = notifcation.userInfo[@"newsImageData"];
    
    self.imageScroll.delegate = self;
    self.imageScroll.backgroundColor = [UIColor blackColor];
    self.imageScroll.contentSize = CGSizeMake(5*self.imageScroll.bounds.size.width, self.imageScroll.bounds.size.height);
    //添加5个button
    
    for (int i = 0 ; i<5; i++) {
        JCHeradNewsImages *images = notifcation.userInfo[@"newsImageData"][i];
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:images.imgsrc]];
        UIButton *button = [[UIButton alloc] init];
        button.frame = CGRectMake(i*self.imageScroll.bounds.size.width, 0, self.imageScroll.bounds.size.width, self.imageScroll.bounds.size.height+100);
       
        
       
        [button setImage:[UIImage imageWithData:data] forState:UIControlStateNormal];
        
        
        [self.imageScroll addSubview:button];
    }
    self.imageScroll.bounces = NO;
    self.imageScroll.pagingEnabled = YES;
    self.imageScroll.showsHorizontalScrollIndicator = NO;
    
    //创建PageControl
    UIPageControl *pc = [[UIPageControl alloc] init];
    self.pc = pc;
    
    pc.frame = CGRectMake(0,self.imageScroll.bounds.size.height - 30, self.imageScroll.bounds.size.width, 40);
    pc.numberOfPages = 5;
    pc.pageIndicatorTintColor = [UIColor whiteColor];
    pc.currentPageIndicatorTintColor = [UIColor blackColor];
    pc.userInteractionEnabled = NO;
    [self.view addSubview:pc];
    
    JCHeradNewsImages *image1 = self.imagesArray[0];
    [self.imageTitle setTitle:image1.title forState:UIControlStateNormal];
    

}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGPoint offset = scrollView.contentOffset;
    self.pc.currentPage = round(offset.x/scrollView.bounds.size.width);
    //NSLog(@"%d",self.pc.currentPage);
    
    JCHeradNewsImages *images = self.imagesArray[self.pc.currentPage];
  [self.imageTitle setTitle:images.title forState:UIControlStateNormal];

}
-(void)listenNewsData:(NSNotification *)notufucation{
    self.newsArray = notufucation.userInfo[@"newData"];
    //右一
    JCHeardNewsData *News = notufucation.userInfo[@"newsData"][1];
    self.fristRightTitle.text = News.title;
    self.fristRightReply.text = [NSString stringWithFormat:@"%@ 跟帖 ",News.replyCount];
    self.fristRightDigst.text = News.digest;
    // 右二
    JCHeardNewsData *News1 = notufucation.userInfo[@"newsData"][2];
    self.secondRightTitle.text = News1.title;
    self.secondRightReply.text = [NSString stringWithFormat:@"%@ 跟帖 ",News1.replyCount];
    self.secondRightDigst.text = News1.digest;
    //右三
    JCHeardNewsData *News2 = notufucation.userInfo[@"newsData"][3];
    self.thirdRightTitle.text = News2.title;
    self.thirdRightReply.text = [NSString stringWithFormat:@"%@ 跟帖 ",News2.replyCount];
    self.thirdRightDigst.text = News2.digest;
    // 下右
    JCHeardNewsData *News3 = notufucation.userInfo[@"newsData"][4];
    self.bottomRightTitle.text = News3.title;
    self.bottomRightRely.text = [NSString stringWithFormat:@"%@ 跟帖 ",News3.replyCount];
    self.bottonRightDigst.text = News3.digest;
    
    // 下左
    JCHeardNewsData *News4 = notufucation.userInfo[@"newsData"][5];
    self.bottomLeftTitle.text = News4.title;
    self.bottomLeftReply.text = [NSString stringWithFormat:@"%@ 跟帖 ",News4.replyCount];
    self.bottomLeftDigst.text = News4.digest;
    
    
}

+(JCContentView *)getContentView{



    return [[[NSBundle mainBundle] loadNibNamed:@"JCContentView" owner:self options:nil]firstObject];
}
- (IBAction)chick:(id)sender {
    JCHeardNewsData *News = self.newsArray[1];
    JCShowViewController *showVC = [[JCShowViewController alloc] init];
    showVC.url = News.url;
    [[UIApplication sharedApplication].keyWindow.rootViewController
     presentViewController:showVC animated:YES completion:nil];
 
    
}



@end
