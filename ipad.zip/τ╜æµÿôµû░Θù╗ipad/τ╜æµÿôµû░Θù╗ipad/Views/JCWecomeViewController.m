//
//  JCWecomeViewController.m
//  网易新闻ipad
//
//  Created by tarena on 16/1/27.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCWecomeViewController.h"
#import "JCMainViewController.h"
@interface JCWecomeViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation JCWecomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSMutableArray *allImage = [NSMutableArray array];
    
    for (NSInteger i = 1; i < 56; i++) {
        NSString *fileName = [NSString stringWithFormat:@"logo%d.png",i];
        
        NSString *path = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
        UIImage *image = [UIImage imageWithContentsOfFile:path];
        
        // 将image对象添加到allImage数组中
        [allImage addObject:image];
    }
    // 设置动画图片数组
    
    [self.imageView setAnimationImages:allImage];
    
    // 设置重复次数
    self.imageView.animationRepeatCount = 1;
    
    // 设置动画时长
    self.imageView.animationDuration = 60*0.075;
    [self.imageView startAnimating];
    
    
    
#warning 寻找更好方法
    [self performSelector:@selector(push) withObject:nil afterDelay:self.imageView.animationDuration - 0.5];
    
//    [UIView animateWithDuration:self.imageView.animationDuration animations:^{
//        [self.imageView startAnimating];
//    } completion:^(BOOL finished) {
//        [self.imageView stopAnimating];
//        [self push];
//    }];
    
    
    

}

-(void)push{
       JCMainViewController *mainVC = [[JCMainViewController alloc] init];
      [self presentViewController:mainVC animated:YES completion:nil];


}


// 开始动画
//[self.imageView startAnimating];

//  经过动画完整时长后，主动将tomImageView的animationImages属性中的数组设置为nil
//[self.imageView performSelector:@selector(setAnimationImages:) withObject:nil afterDelay:self.imageView.animationDuration];
//
//    self.imageView.image = [UIImage imageNamed:@"logo56"];
//    [UIView beginAnimations:nil context:nil];
//   [UIView setAnimationDelegate:self];
////
//   [UIView commitAnimations];
//[UIView setAnimationDidStopSelector:@selector(push)];
//
////    JCMainViewController *mainVC = [[JCMainViewController alloc] init];
////    [self presentViewController:mainVC animated:YES completion:nil];
@end
