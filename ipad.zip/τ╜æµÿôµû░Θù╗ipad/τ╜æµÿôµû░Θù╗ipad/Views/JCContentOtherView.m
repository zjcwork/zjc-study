//
//  JCContentOtherView.m
//  网易新闻ipad
//
//  Created by tarena on 16/2/18.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCContentOtherView.h"
#import "JCHeardNewsData.h"
#import "UIImageView+WebCache.h"
@interface JCContentOtherView()
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *titleArray;
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *imageArray;
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *replyCountArray;

@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *digestArray;
@property ( nonatomic) int pageNumber;
@property (nonatomic, strong) NSArray *newsArray;
@property (nonatomic ) int i ;




@end
@implementation JCContentOtherView

+(JCContentOtherView *)getContentOtherView{

    
    return [[[NSBundle mainBundle] loadNibNamed:@"JCContentOtherView" owner:self options:nil]firstObject];

}

-(void)awakeFromNib{
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenNewsData:) name:@"getNewsData" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenpageNumber:) name:@"pageNumber" object: nil];
    
   
    
    
}


-(void)listenpageNumber:(NSNotification *)notifucation{

    self.pageNumber = [notifucation.userInfo[@"pageNumber"] intValue];
    NSLog(@"接收到第%d页",self.pageNumber);
    
    
       [self change];
    
}
-(void)change{
    for (NSInteger index = 0; index <6; index++) {
        UILabel *titleLabel = self.titleArray[index];
        UILabel *replyCountLabel = self.replyCountArray[index];
        UILabel *digestLabel = self.digestArray[index];
        
        
        JCHeardNewsData * newsData = self.newsArray[index+(6 * self.pageNumber)];
        
        titleLabel.text = newsData.title;
        replyCountLabel.text = [NSString stringWithFormat:@"%@ 跟帖 ",newsData.replyCount];
        digestLabel.text = newsData.digest;
        
        if (index <3 ) {
//            NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:newsData.imgsrc]];
              UIImageView *image = self.imageArray[index];
//            image.image = [UIImage imageWithData:imageData];
            // image = [UIImage imageWithData:imageData];
            [image sd_setImageWithURL:[NSURL URLWithString:newsData.imgsrc] placeholderImage:[UIImage imageNamed:@"占位.pjg"]];
            
        }
        
    }
    




}
-(void)listenNewsData:(NSNotification *)notifucation{
    
    self.newsArray = notifucation.userInfo[@"newsData"];

 
}


@end
