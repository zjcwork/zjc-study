//
//  JCLoadingView.m
//  网易新闻ipad
//
//  Created by tarena on 16/2/19.
//  Copyright © 2016年 ZJC. All rights reserved.
//

#import "JCLoadingView.h"
#import "RTSpinKitView.h"
#import "Masonry.h"
@implementation JCLoadingView

-(instancetype)init{

    if (self = [super init]) {
        RTSpinKitView *sp = [[RTSpinKitView alloc] initWithStyle:RTSpinKitViewStyleWave color:[UIColor redColor]];
        
        sp.frame = CGRectMake(450, 300, 200, 40);
        [self addSubview:sp];
    }
    return self;

}

@end
